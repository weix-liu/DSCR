import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from model.utils.net_utils import grad_reverse
from torch.autograd import Variable

class fineDSCRModule(nn.Module):
    def __init__(self, channels,num_domains, reduction, k=7):
        super(fineDSCRModule, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(k)
        self.fc1_list = nn.ModuleList([nn.Conv2d(channels, channels // reduction, kernel_size=1,
                             padding=0) for i in range(num_domains)])
        self.relu = nn.ReLU(inplace=True)
        self.fc2 = nn.Conv2d(channels // reduction, channels, kernel_size=1,
                             padding=0)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, domain_label=0):
        y = self.avg_pool(x)

        y = self.fc1_list[domain_label](y)
        y = self.relu(y)
        y = self.fc2(y)

        y = self.sigmoid(y)
        y = F.upsample(y,size=x.size()[2:],mode='bilinear')
        out = y*x
        return out

class SE(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(SE, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)

        self.fc = nn.Sequential(nn.Conv2d(in_planes, in_planes // 16, 1, bias=False),
                                nn.ReLU(),
                                nn.Conv2d(in_planes // 16, in_planes, 1, bias=False))
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        out = self.fc(self.avg_pool(x))
        return x*self.sigmoid(out)

